
public class Company {
    private String name;
    private String shortTitle;
    private String dateUpdate;
    private Integer dateFoundation;
    private Integer countEmployees;
    private String phone;
    private String email;
    private String branch;
    private String activity;


    public Company(String str, String delimiter) {
        String arr[] = str.split(delimiter);
        this.name = arr[0];
        this.shortTitle = arr[1];
        this.dateUpdate = arr[2];
        this.dateFoundation = Integer.valueOf(arr[3]);
        this.countEmployees = Integer.valueOf(arr[4]);
        this.phone = arr[5];
        this.email = arr[6];
        this.branch = arr[7];
        this.activity = arr[8];
    }

    public Company() {

    }

    public String getBranch() {
        return branch;
    }

    public String getName() {
        return name;
    }

    public String getDateUpdate() {
        return dateUpdate;
    }

    public String getShortTitle() {
        return shortTitle;
    }

    public Integer getDateFoundation() {
        return dateFoundation;
    }

    public Integer getCountEmployees() {
        return countEmployees;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getActivity() {
        return activity;
    }

    @Override
    public String toString() {
        return "\nИмя = " + getName() + " ::Короткое название = " + getShortTitle() + " ::Дата актуализации = " +
                getDateUpdate() + "\n::Дата основания = " + getDateFoundation() + " ::Количество работников = "
                + getCountEmployees() + " ::Номер телефона " +
                getPhone() + "\n::Email = " + getEmail() + " ::Отрасль = " + getBranch() + " ::Вид деятельности = " + getActivity() + "\n";
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setShortTitle(String shortTitle) {
        this.shortTitle = shortTitle;
    }

    public void setDateUpdate(String dateUpdate) {
        this.dateUpdate = dateUpdate;
    }

    public void setDateFoundation(String dateFoundation) {
        this.dateFoundation = Integer.valueOf(dateFoundation);
    }

    public void setCountEmployees(String countEmployees) {
        this.countEmployees = Integer.valueOf(countEmployees);
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }
}


