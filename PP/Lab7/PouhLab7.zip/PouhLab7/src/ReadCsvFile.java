import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.stream.Stream;

public class ReadCsvFile {
    public static void main(String[] args) throws IOException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();

        FileReader isr2 = new FileReader("comp.csv");
        BufferedReader fileIn = new BufferedReader(isr2);

        FileWriter file1xml = new FileWriter("out.xml");
        BufferedWriter xmlWrite = new BufferedWriter(file1xml);

        ArrayList<Company> companiesFile = new ArrayList<>();
        Stream<String> inputs = fileIn.lines();
        inputs.forEach(s -> companiesFile.add(new Company(s, ";")));

        companiesFile.forEach(obj -> {
            try {
                xmlWrite.write(obj.toString());
                xmlWrite.newLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        xmlWrite.close();

        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader sysIn = new BufferedReader(isr);

        FileWriter file1txt = new FileWriter("logfile.txt", true);
        BufferedWriter loggerTxt = new BufferedWriter(file1txt);
        FileWriter file1json = new FileWriter("out.json");
        BufferedWriter jsonWrite = new BufferedWriter(file1json);

        companiesFile.forEach(obj -> {
            try {
                jsonWrite.write(obj.toString());
                jsonWrite.newLine();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        jsonWrite.close();

        loggerTxt.write("Start: <" + formatter.format(date) + ">");
        loggerTxt.newLine();

        Integer counter = 0;

        System.out.println("Write short title of company to search for: ");
        String name = sysIn.readLine().toLowerCase();
        System.out.println("Results");
        for (Company u : companiesFile) {
            if (u.getShortTitle().toLowerCase().compareTo(name) == 0) {
                System.out.println(u);
                counter++;
            }
        }
        System.out.println();

        loggerTxt.write("Was searched by: <" + name + ">, found: " + counter);
        loggerTxt.newLine();

        counter = 0;

        System.out.println("Write branch of company to search for: ");
        String branch = sysIn.readLine().toLowerCase();
        System.out.println("Results");
        for (Company u : companiesFile) {
            if (u.getBranch().toLowerCase().compareTo(branch) == 0) {
                System.out.println(u);
                counter++;
            }
        }
        System.out.println();

        loggerTxt.write("Was searched  by branch: <" + branch + ">, Found: " + counter);
        loggerTxt.newLine();

        counter = 0;

        System.out.println("Write activity of company to search for: ");
        String activity = sysIn.readLine().toLowerCase();
        System.out.println("Результаты");
        for (Company u : companiesFile) {
            if (u.getActivity().toLowerCase().compareTo(activity) == 0) {
                System.out.println(u);
                counter++;
            }
        }
        System.out.println();

        loggerTxt.write("Was searched by activity: <" + activity + ">, Found: " + counter);
        loggerTxt.newLine();

        counter = 0;

        System.out.println("Write data of foundation to search for: ");
        System.out.print("Date from: ");
        Integer firstData = Integer.parseInt(sysIn.readLine());
        System.out.print("Date to: ");
        Integer lastData = Integer.parseInt(sysIn.readLine());
        System.out.println("Results");
        for (Company u : companiesFile) {
            if (u.getDateFoundation() >= firstData && u.getDateFoundation() <= lastData) {
                System.out.println(u);
                counter++;
            }
        }
        System.out.println();

        loggerTxt.write("It was searched by date of foundation in interval [" + firstData + "," + lastData + "], found: " + counter);
        loggerTxt.newLine();

        counter = 0;

        System.out.println("write count of employees to search for: ");
        System.out.print("Min: ");
        Integer min = Integer.parseInt(sysIn.readLine());
        System.out.print("Max: ");
        Integer max = Integer.parseInt(sysIn.readLine());
        System.out.println("Results");
        for (Company u : companiesFile) {
            if (u.getCountEmployees() >= min && u.getCountEmployees() <= max) {
                System.out.println(u);
                counter++;
            }
        }
        System.out.println();

        loggerTxt.write("It was searched by the number of employees in the range [" + min + "," + max + "], found: " + counter);
        loggerTxt.newLine();

        loggerTxt.close();
    }
}